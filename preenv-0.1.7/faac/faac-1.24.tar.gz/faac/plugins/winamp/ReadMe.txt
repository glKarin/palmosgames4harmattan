+-----------------------------------------------------------------+
|                                                                 |
|                          out_FAAC Readme                        |
|                          ---------------                        |
|                                                                 |
+-----------------------------------------------------------------+

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

----------------------------------------------------------------------------

out_AAC is an encoder plugin for Winamp 2 and 5.

To use it:
----------

In visual studio set "Active Configuration = out_FAAC - win32 Release" and compile then
copy out_AAC.dll into Winamp\plugins folder.

----------------------------------------------------------------------------

For suggestions, bugs report, etc., you can contact me at
ntnfrn_email-temp@yahoo.it
